{
  "id": "pameran-artefak-megalitik-lembah-bada",
  "title": "Pameran Artefak Megalitik Lembah Bada",
  "short_description": "Pameran khusus menampilkan koleksi artefak megalitik dari Lembah Bada yang penuh misteri dan sejarah peradaban kuno Sulawesi Tengah.",
  "image_url": "https://placehold.co/800x400/a3b18a/ffffff?text=Pameran+Artefak",
  "date": "2025-06-15",
  "time": "09:00 - 17:00 WITA",
  "location": "Ruang Pameran Utama, Lantai 2",
  "capacity": "100 orang per sesi",
  "full_description": [
    "Pameran Artefak Megalitik Lembah Bada merupakan pameran khusus yang menampilkan koleksi lengkap artefak megalitik dari Lembah Bada, salah satu situs arkeologi paling penting di Sulawesi Tengah.",
    "Lembah Bada terkenal dengan patung-patung megalitik yang misterius, yang diperkirakan berasal dari abad ke-13 hingga ke-15 Masehi. Patung-patung ini, yang dikenal dengan nama \"Arca Bada\", memiliki bentuk yang unik dan masih menyimpan banyak misteri tentang peradaban yang membuatnya.",
    "Dalam pameran ini, pengunjung akan dapat melihat: Replika patung megalitik dalam ukuran asli - Artefak tembikar dan perhiasan kuno - Dokumentasi proses penelitian arkeologi - Rekonstruksi kehidupan masyarakat kuno Lembah Bada - Film dokumenter tentang sejarah dan budaya Lembah Bada.",
    "Pameran ini juga dilengkapi dengan teknologi AR (Augmented Reality) yang memungkinkan pengunjung untuk melihat rekonstruksi digital dari situs asli Lembah Bada."
  ],
  "details": {
    "price": "Gratis",
    "organizer": "Museum Sulawesi Tengah",
    "contact": "+62 451 421234",
    "status": "Akan Datang"
  },
  "schedule": [
    {
      "time": "09:00 - 10:00",
      "activity": "Pembukaan dan Sambutan"
    },
    {
      "time": "10:00 - 12:00",
      "activity": "Tur Pameran Terpandu"
    }
  ]
}